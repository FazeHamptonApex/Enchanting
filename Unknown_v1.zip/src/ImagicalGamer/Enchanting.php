<?php
namespace ImagicalGamer;

use pocketmine\plugin\PluginBase;

/* Copyright (C) ImagicalGamer - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Jake C <imagicalgamer@outlook.com>, May 2017
 */

class Enchanting extends PluginBase{

  public function onEnable()
  {
    $name = $this->getServer()->getName();

    if($name === "PMMP" or $name === "PocketMine-MP")
    {
      $this->getLogger()->warning("Enchanting v1.0.0 doesnt fully support " . $name . " you may encounter issues!");
    }
    $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
  }
}