<?php
namespace ImagicalGamer;

use pocketmine\event\Listener;

use pocketmine\item\Item;
use pocketmine\item\Dye;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentLevelTable;

use pocketmine\block\EnchantingTable;
use pocketmine\block\Block;

use pocketmine\event\player\PlayerInteractEvent;

/* Copyright (C) ImagicalGamer - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Jake C <imagicalgamer@outlook.com>, May 2017
 */

class EventListener implements Listener{

	private $plugin;

	public function __construct(Enchanting $plugin)
	{
		$this->plugin = $plugin;
	}

	public function onInteract(PlayerInteractEvent $ev)
	{
		$p = $ev->getPlayer();
		$b = $ev->getBlock();
		$it = $p->getInventory()->getItemInHand();

		if(!$b instanceof EnchantingTable)
		{
			return;
		}
		if($it->getId() === 0)
		{
			return;
		}
		if($it->hasEnchantments())
		{
			return;
		}

		$ev->setCancelled(True);

	    /*$lapis = Item::get(Item::DYE, Dye::BLUE, mt_rand(1, 3));
	    $contains = false;

	    foreach($p->getInventory()->getContents() as $item)
	    {
	    	if($item->getId() !== $lapis->getId())
	    	{
	    		continue;
	    	}
	    	if($item->getDamage() !== $lapis->getDamage())
	    	{
	    		continue;
	    	}
	    	if(!$item->getCount() >= $lapis->getCount())
	    	{
	    		continue;
	    	}
	    	$contians = true;
	    	break;
	    }

	    if(!$contains)
	    {
	    	return;
	    }*/

	    $enchantAbility = Enchantment::getEnchantAbility($it);

	    $amount = mt_rand(0, 15);
	    $base = mt_rand(1, 8) + ($amount / 2) + mt_rand(0, $amount);
	    $levels = [
	    	0 => max($base / 3, 1),
			1 => (($base * 2) / 3 + 1),
			2 => max($base, $amount * 2)
		];
	    for($i = 0; $i < 3; $i++)
	    {
	    	$level = $levels[$i];
			$k = $level + mt_rand(0, round(round($enchantAbility / 4) * 2)) + 1;
			$bonus = (((0 + mt_rand() / mt_getrandmax() * (1 - 0)) - 1) + (0 + mt_rand() / mt_getrandmax() * (1 - 0)) - 1) * 0.15 + 1;
			$modifiedLevel = ($k * (1 + $bonus) + 0.5);

			$possible = EnchantmentLevelTable::getPossibleEnchantments($it, $modifiedLevel);
			$weights = [];
			$total = 0;

			if($p->getXpLevel() < $level)
			{
				return;
			}

			for($j = 0; $j < count($possible); $j++)
			{
				$id = $possible[$j]->getId();
				$weight = Enchantment::getEnchantWeight($id);
				$weights[$j] = $weight;
				$total += $weight;
			}

			$v = mt_rand(1, $total + 1);
			$sum = 0;
			for($key = 0; $key < count($weights); ++$key)
			{
				$sum += $weights[$key];
				if($sum >= $v)
				{
					$key++;
					break;
				}
			}

			$key--;

			if(!isset($possible[$key]))
			{
				return;
			}

			$enchantment = $possible[$key];
			$result[] = $enchantment;
			unset($possible[$key]);

			foreach($result as $ench)
			{
				$it->addEnchantment($ench);
			}

			$p->takeXpLevel($level);
			$p->getInventory()->setItemInHand($it);
			//$p->getInventory()->removeItem($lapis);
			return;
	    }
	}
}